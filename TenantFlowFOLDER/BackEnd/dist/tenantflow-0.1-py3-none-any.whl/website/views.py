from flask import Blueprint, render_template, request, flash, jsonify, send_file, redirect, url_for
from flask_login import login_required, current_user
from .models import *
from . import db
from .utils import (
    generate_tenant_qr,
    create_payment_reminder,
    check_overdue_payments,
    format_currency
)
from datetime import datetime

views = Blueprint('views', __name__)

@views.route('/')
@login_required
def home():
    # Check for overdue payments
    if current_user.user_type == 'tenant':
        notifications = check_overdue_payments()
        for notification in notifications:
            db.session.add(notification)
        db.session.commit()
    
    return render_template("home.html", user=current_user)

@views.route('/generate-qr')
@login_required
def generate_qr():
    try:
        # Generate QR code for tenant info
        tenant_data = {
            'id': current_user.id,
            'email': current_user.email,
            'name': current_user.first_name
        }
        qr_buffer = generate_tenant_qr(tenant_data)
        
        if qr_buffer is None:
            flash('Error generating QR code. Please check if qrcode module is installed.', category='error')
            return redirect(url_for('views.home'))
            
        return send_file(
            qr_buffer,
            mimetype='image/png',
            as_attachment=True,
            download_name='tenant_qr.png'
        )
    except Exception as e:
        print(f"Error in generate_qr route: {str(e)}")
        flash('Error generating QR code', category='error')
        return redirect(url_for('views.home'))

@views.route('/notifications')
@login_required
def get_notifications():
    notifications = Notification.query.filter_by(
        user_id=current_user.id,
        is_read=False
    ).all()
    return jsonify([{
        'id': n.id,
        'message': n.message,
        'type': n.type,
        'created_date': n.created_date.strftime('%Y-%m-%d %H:%M:%S')
    } for n in notifications])

@views.route('/mark-notification-read/<int:notification_id>', methods=['POST'])
@login_required
def mark_notification_read(notification_id):
    notification = Notification.query.get_or_404(notification_id)
    if notification.user_id == current_user.id:
        notification.is_read = True
        db.session.commit()
        return jsonify({'success': True})
    return jsonify({'success': False}), 403

@views.route('/dashboard')
@login_required
def dashboard():
    if current_user.user_type == UserType.ADMIN.value:
        units = Unit.query.all()
        payments = Payment.query.all()
        maintenance_requests = MaintenanceRequest.query.all()
        return render_template(
            "admin_dashboard.html", 
            units=units,
            payments=payments,
            maintenance_requests=maintenance_requests
        )
    elif current_user.user_type == UserType.TENANT.value:
        unit = Unit.query.filter_by(current_tenant_id=current_user.id).first()
        payments = Payment.query.filter_by(tenant_id=current_user.id).all()
        return render_template(
            "tenant_dashboard.html",
            unit=unit,
            payments=payments
        )
    
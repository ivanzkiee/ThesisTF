try:
    import qrcode
except ImportError:
    print("Error: qrcode module not installed. Please run 'pip install qrcode pillow'")
    qrcode = None

import json
from io import BytesIO
from datetime import datetime, timedelta
from .models import Notification, Payment, User
from flask import current_app

def generate_tenant_qr(tenant_data):
    """
    Generate QR code for tenant data
    Args:
        tenant_data (dict): Dictionary containing tenant information
    Returns:
        BytesIO: QR code image in memory buffer
    """
    if qrcode is None:
        print("QR code functionality not available - qrcode module not installed")
        return None
        
    try:
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        
        # Convert tenant data to JSON string
        qr.add_data(json.dumps(tenant_data))
        qr.make(fit=True)
        
        # Create QR code image
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Save image to memory buffer
        buffer = BytesIO()
        img.save(buffer, format="PNG")
        buffer.seek(0)
        
        return buffer
        
    except Exception as e:
        print(f"Error generating QR code: {str(e)}")
        return None

def create_payment_reminder(user_id, amount_due, due_date):
    """
    Create payment reminder notification
    Args:
        user_id (int): ID of user to notify
        amount_due (float): Amount due for payment
        due_date (datetime): Payment due date
    """
    message = f"Payment reminder: ₱{amount_due:.2f} due on {due_date.strftime('%B %d, %Y')}"
    notification = Notification(
        user_id=user_id,
        message=message,
        type="payment_reminder"
    )
    return notification

def check_overdue_payments():
    """
    Check for overdue payments and create notifications
    Returns:
        list: List of created notifications
    """
    notifications = []
    today = datetime.utcnow()
    
    try:
        # Get pending payments
        upcoming_payments = Payment.query.filter(
            Payment.status == "pending"
        ).all()
        
        for payment in upcoming_payments:
            try:
                tenant = User.query.get(payment.tenant_id)
                if not tenant:
                    print(f"No tenant found for payment {payment.id}")
                    continue

                # Skip if no due date
                if not payment.due_date:
                    print(f"No due date for payment {payment.id}")
                    continue

                days_until_due = (payment.due_date - today).days
                
                if days_until_due <= 0:
                    message = (
                        f"OVERDUE: Payment of {format_currency(payment.amount)} "
                        f"was due on {payment.due_date.strftime('%B %d, %Y')}"
                    )
                elif days_until_due <= 5:  # Only notify for upcoming 5 days
                    message = (
                        f"Upcoming payment: {format_currency(payment.amount)} "
                        f"due in {days_until_due} days"
                    )
                else:
                    continue  # Skip if due date is more than 5 days away
                    
                notification = Notification(
                    user_id=tenant.id,
                    message=message,
                    type="payment_reminder"
                )
                notifications.append(notification)
                
            except Exception as e:
                print(f"Error processing payment {payment.id}: {str(e)}")
                continue
                
    except Exception as e:
        print(f"Error in check_overdue_payments: {str(e)}")
        
    return notifications

def format_currency(amount):
    """
    Format currency amount with peso sign and proper decimal places
    Args:
        amount (float): Amount to format
    Returns:
        str: Formatted currency string
    """
    return f"₱{amount:,.2f}"

def get_maintenance_status_color(status):
    """
    Get bootstrap color class for maintenance status
    Args:
        status (str): Maintenance request status
    Returns:
        str: Bootstrap color class
    """
    status_colors = {
        'pending': 'warning',
        'in_progress': 'info',
        'completed': 'success',
        'cancelled': 'danger'
    }
    return status_colors.get(status, 'secondary') 
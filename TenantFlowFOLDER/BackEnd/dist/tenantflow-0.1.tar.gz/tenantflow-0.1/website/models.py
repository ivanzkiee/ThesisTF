from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func
from datetime import datetime
from enum import Enum


class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.String(10000))
    date = db.Column(db.DateTime(timezone=True), default=func.now())
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))


class UserType(Enum):
    ADMIN = "admin"
    TENANT = "tenant"
    MAINTENANCE = "maintenance"

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    user_type = db.Column(db.String(50), default='tenant')
    unit_number = db.Column(db.String(50))  # For tenants
    balance = db.Column(db.Float, default=0)
    notifications = db.relationship('Notification')
    payments = db.relationship('Payment')
    notes = db.relationship('Note')

class Unit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    unit_number = db.Column(db.String(50), unique=True)
    status = db.Column(db.String(50))  # vacant/occupied/maintenance
    floor = db.Column(db.Integer)
    building = db.Column(db.String(150))
    current_tenant_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    rent_amount = db.Column(db.Float)
    last_maintenance_date = db.Column(db.DateTime)

class MaintenanceRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    unit_id = db.Column(db.Integer, db.ForeignKey('unit.id'))
    tenant_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    description = db.Column(db.String(500))
    priority = db.Column(db.String(50))
    status = db.Column(db.String(50))
    created_date = db.Column(db.DateTime, default=datetime.utcnow)
    assigned_to = db.Column(db.Integer, db.ForeignKey('user.id'))

class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    amount = db.Column(db.Float)
    due_date = db.Column(db.DateTime, nullable=True)  # Make nullable to avoid errors
    payment_date = db.Column(db.DateTime, nullable=True)
    status = db.Column(db.String(50), default='pending')  # pending, paid, overdue
    created_date = db.Column(db.DateTime, default=datetime.utcnow)

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    message = db.Column(db.String(500))
    type = db.Column(db.String(50))  # payment_reminder/maintenance/announcement
    created_date = db.Column(db.DateTime, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)


from setuptools import setup, find_packages

setup(
    name="tenantflow",
    version="0.1",
    packages=find_packages(),
    install_requires=[
        "Flask>=2.0.1,<2.1.0",
        "Flask-SQLAlchemy>=2.5.1,<2.6.0",
        "Flask-Login>=0.5.0,<0.6.0",
        "Werkzeug>=2.0.1,<2.1.0",
        "Flask-WTF>=0.15.1,<0.16.0",
        "qrcode>=6.1,<7.0",
        "Pillow>=7.2.0,<8.0.0",
        "MarkupSafe>=2.0.1,<2.1.0",
        "Jinja2>=3.0.1,<3.1.0",
        "SQLAlchemy>=1.4.23,<1.5.0",
        "WTForms>=2.3.3,<2.4.0",
    ],
    python_requires=">=3.8,<3.10",
) 